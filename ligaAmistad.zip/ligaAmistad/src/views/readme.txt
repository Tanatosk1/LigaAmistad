Carpeta para los ficheros con la interface de la aplicación
