Carpeta para los archivos de conección con la BBDD
