Carpeta para los ficheros de código de la aplicación
